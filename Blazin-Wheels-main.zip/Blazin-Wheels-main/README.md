# Blazin-Wheels
This app is basically a learning platform for non-car enthusiasts who wants to know more about cars.
